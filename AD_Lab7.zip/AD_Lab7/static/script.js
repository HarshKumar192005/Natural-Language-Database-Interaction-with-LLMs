document.getElementById("query-form").addEventListener("submit", function(event) {
    event.preventDefault();
    const query = document.getElementById("query").value;

    fetch("/query", {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify({ query: query })
    })
    .then(response => response.json())
    .then(data => {
        document.getElementById("sql-query").textContent = data.query || "Error: No SQL generated";
        
        if (data.result) {
            const tableHead = document.querySelector("#results-table thead");
            const tableBody = document.querySelector("#results-table tbody");

            // Clear previous results
            tableHead.innerHTML = "";
            tableBody.innerHTML = "";

            if (data.result.length > 0) {
                // Create table headers
                const headers = Object.keys(data.result[0]);
                const headRow = document.createElement("tr");
                headers.forEach(header => {
                    const th = document.createElement("th");
                    th.textContent = header;
                    headRow.appendChild(th);
                });
                tableHead.appendChild(headRow);

                // Create table rows
                data.result.forEach(row => {
                    const tr = document.createElement("tr");
                    headers.forEach(header => {
                        const td = document.createElement("td");
                        td.textContent = row[header];
                        tr.appendChild(td);
                    });
                    tableBody.appendChild(tr);
                });
            } else {
                tableBody.innerHTML = "<tr><td colspan='100%'>No results found</td></tr>";
            }
        }
    })
    .catch(error => console.error("Error:", error));
});
