import mysql.connector

DB_USER = "root"
DB_PASSWORD = "harsh2004@"  # Use your actual MySQL password
DB_HOST = "127.0.0.1"  # Ensure it's 127.0.0.1 or localhost
DB_PORT = "3306"  # Default MySQL port
DB_NAME = "nl2sql"  # Use your actual database name

try:
    conn = mysql.connector.connect(
        host=DB_HOST,
        user=DB_USER,
        password=DB_PASSWORD,
        database=DB_NAME,
        port=DB_PORT
    )
    print("✅ Database Connection Successful!")
    conn.close()
except mysql.connector.Error as err:
    print(f"❌ Database Connection Error: {err}")
